﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace COMP1551_Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a string (A-Z only, max 40): ");
            string input = Console.ReadLine().ToUpper();

            if (input.Length > 40 || !input.All(c => c >= 'A' && c <= 'Z'))
            {
                Console.WriteLine("Invalid input. Please use A-Z characters only and max 40 characters.");
                return;
            }

            Console.Write("Enter N (-25 to 25): ");
            int n = int.Parse(Console.ReadLine());
            if (n < -25 || n > 25)
            {
                Console.WriteLine("Invalid N value. It must be between -25 and 25.");
                return;
            }

            // Sort input string and ASCII
            string sortedString = new string(input.OrderBy(c => c).ToArray());
            List<int> sortedAsciiCodes = sortedString.Select(c => (int)c).ToList();

            // Encoding method options
            Console.WriteLine("\nChoose encoding method:");
            Console.WriteLine(" 0. Demo all methods");
            Console.WriteLine(" 1. Caesar Cipher");
            Console.WriteLine(" 2. Atbash Cipher");
            Console.WriteLine(" 3. Adjacent Swap");
            Console.WriteLine(" 4. Vowel Replacer");
            Console.WriteLine(" 5. Mirror Mode");
            Console.Write("Your choice: ");
            int choice = int.Parse(Console.ReadLine());

            Console.WriteLine($"\nSorted String   : {sortedString}");
            Console.WriteLine($"Sorted ASCII    : {string.Join(", ", sortedAsciiCodes)}");

            switch (choice)
            {
                case 0:
                    for (int m = 1; m <= 5; m++)
                    {
                        StringProcessorBase proc;
                        string name;
                        switch (m)
                        {
                            case 1: proc = new CaesarProcessor(input, n); name = "Caesar Cipher"; break;
                            case 2: proc = new AtbashProcessor(input); name = "Atbash Cipher"; break;
                            case 3: proc = new AdjacentSwapProcessor(input); name = "Adjacent Swap"; break;
                            case 4: proc = new VowelReplacerProcessor(input); name = "Vowel Replacer"; break;
                            case 5: proc = new MirrorProcessor(input); name = "Mirror Mode"; break;
                            default: continue;
                        }

                        Console.WriteLine($"\n--- {name} (method {m}) ---");
                        Console.WriteLine($"Encoded      : {proc.Print()}");
                        Console.WriteLine($"Input ASCII  : {string.Join(", ", proc.InputCode())}");
                        Console.WriteLine($"Output ASCII : {string.Join(", ", proc.OutputCode())}");
                    }
                    break;

                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    StringProcessorBase processor = null;
                    switch (choice)
                    {
                        case 1: processor = new CaesarProcessor(input, n); break;
                        case 2: processor = new AtbashProcessor(input); break;
                        case 3: processor = new AdjacentSwapProcessor(input); break;
                        case 4: processor = new VowelReplacerProcessor(input); break;
                        case 5: processor = new MirrorProcessor(input); break;
                    }

                    Console.WriteLine($"\nEncoded      : {processor.Print()}");
                    Console.WriteLine($"Input ASCII  : {string.Join(", ", processor.InputCode())}");
                    Console.WriteLine($"Output ASCII : {string.Join(", ", processor.OutputCode())}");
                    break;

                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
